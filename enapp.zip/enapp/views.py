from django.shortcuts import render
from .forms import EnForm
from .models import EnModel

def home(request):
   if request.method=="POST":
       na=request.POST.get("name")
       ph=int(request.POST.get("phone"))
       su=request.POST.get("subject")
       data=EnModel(name=na,phone=ph,subject=su)
       data.save()
       msg="we will get back yo you"
       fm=EnForm()
       return render(request,"home.html",{"fm":fm,"msg":msg})
   else:
        fm=EnForm()
        return render(request,"home.html",{"fm":fm})